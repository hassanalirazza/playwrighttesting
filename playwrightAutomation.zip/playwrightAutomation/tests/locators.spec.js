const { test, expect } = require('@playwright/test');

test('Home page',async ({page})=> {
   await page.goto('https://www.demoblaze.com/');


   //click on login button - prroperty
   //await page.locator('id=login2').click()
   await page.click('id=login2')


   //provide username - CSS
   //await page.locator('#loginusername').fill("pavanol")
   //await page.fill('#loginusername','pavanol')
   //await page.type('#loginusername','pavanol')

})



//Npx playwright test locators.spec.js -–project=chromium -–headed