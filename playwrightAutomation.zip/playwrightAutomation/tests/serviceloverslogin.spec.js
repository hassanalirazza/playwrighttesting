const { test, expect } = require('@playwright/test');



const email = "support+flammen12@servicelovers.com";
const prodemail = "support+flammen@servicelovers.com";
const devUrl = "https://adminpanel-dev.servicelovers.com/login";
const stageUrl = "https://adminpanel-stage.servicelovers.com/login";
const prodUrl = "https://adminpanel.servicelovers.com/login";
const companyName = "Testing company"
const companyAddress = "test adress 123"
const companyZipCode = "test zipp 123"

test('Home page',async ({page})=> {
   await page.goto(devUrl);
   const pageTitle =await page.title();
   console.log('pageTitle is ', pageTitle);


   await expect(page).toHaveTitle('Servicelovers');
   const pageUrl =await page.url();
   console.log('page url is ', pageUrl);
   await expect(page).toHaveURL('https://adminpanel-dev.servicelovers.com/login')
   // enter email

   // await page.locator('id=email').fill("support+flammen12@servicelovers.com")
   await page.locator('id=email').fill(email)
   // Enter password
   await page.locator('id=password').fill("123456")
   //Click login
   await page.click("button[type='submit']")


   //Click Servicelovers
   await page.click("body div[id='root'] div[class='ant-layout css-caty08'] div[class='ant-layout ant-layout-has-sider css-caty08'] div[class='sc-hHftDr kCQmsc'] aside[class='ant-layout-sider ant-layout-sider-light'] div[class='ant-layout-sider-children'] ul[role='menu'] li:nth-child(4) div:nth-child(1) span:nth-child(1) span:nth-child(1)")
   //Click company 
   await page.click("a[href='/admin/servicelovers/companies']")
   

   //Click Create company 
   await page.click("button[class='ant-btn css-caty08 ant-btn-primary sc-dHntBn hoynti sc-bIMZcE bmHBqe']")
   //await page.click(".ant-btn css-caty08 ant-btn-primary sc-dHntBn hoynti sc-ksSWxP gSHsI")


   // write company name
   await page.locator("input[placeholder='Company name']").fill(companyName)

   // write address
   await page.locator("input[placeholder='Address - Street name and house number']").fill(companyAddress)

   // write company zip code
   await page.locator("input[placeholder='Zip code']").fill(companyZipCode)

   //select industry dropdown
   const disabledDropdown = await page.$("#/div[5]//span[2]//span[1]//*[name()='svg']")
    //await page.$('selector-for-disabled-dropdown');

   // Get the value from the disabled dropdown
   const dropdownValue = await disabledDropdown.evaluate(el => el.value);
 
   console.log(dropdownValue)

   //select dropdown value
   // await page.click("#/div[5]//span[2]//span[1]//*[name()='svg']")
   //await page.click("//span[@class='ant-tooltip-open']")
   await page.click(".ant-tooltip-open")







   



   //#email#password-button[type='submit']


   //await page.close();
   
})





//command : npx playwright test serviceloverslogin.spec.js --project=chromium --headed
//debug command npx playwright test serviceloverslogin.spec.js --project=chromium --headed --debug